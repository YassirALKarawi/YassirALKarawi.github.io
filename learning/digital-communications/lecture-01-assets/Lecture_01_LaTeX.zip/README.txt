LECTURE 01 - INTRODUCTION TO DIGITAL COMMUNICATION
Dr. Yassir Al-Ameen

Compile main.tex with pdfLaTeX twice.
For Overleaf, upload the complete ZIP and select main.tex.
All required vector figures and photographs are included.
This student edition follows a short explanation, visual, example and practice sequence.
Source acknowledgment and photograph credits appear in the PDF.
