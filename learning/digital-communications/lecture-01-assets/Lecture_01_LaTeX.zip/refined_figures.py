from pathlib import Path
import numpy as np
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch,Rectangle,Circle,Arc,Polygon
P=Path(__file__).parent/'assets'
B='#2563A6';T='#008B83';O='#D99124';R='#C55365';N='#183348';G='#63788B'
plt.rcParams.update({'font.family':'DejaVu Sans','font.size':11,'axes.titlesize':12,'axes.titleweight':'bold','axes.labelsize':10,'axes.spines.top':False,'axes.spines.right':False,'axes.edgecolor':'#BBC9D2','text.color':N,'axes.labelcolor':N,'xtick.color':G,'ytick.color':G,'legend.fontsize':9,'pdf.fonttype':42,'lines.linewidth':2})
def save(f,n):f.savefig(P/(n+'.pdf'),bbox_inches='tight',pad_inches=.12);plt.close(f)
def canvas(h=4):
 f,a=plt.subplots(figsize=(8,h));a.set(xlim=(0,12),ylim=(0,h*1.5));a.axis('off');return f,a

def icon(a,x,y,k,c=T,s=.5):
 def line(xs,ys):a.plot(x+s*np.array(xs),y+s*np.array(ys),color=c,lw=1.8,solid_capstyle='round')
 if k=='mic':
  a.add_patch(FancyBboxPatch((x-.22*s,y-.1*s),.44*s,.85*s,boxstyle='round,pad=.01,rounding_size=.1',fc=c+'15',ec=c,lw=1.7));a.add_patch(Arc((x,y+.13*s),.85*s,.95*s,theta1=180,theta2=360,ec=c,lw=1.7));line([0,0],[-.36,-.7]);line([-.35,.35],[-.7,-.7])
 elif k in ['chip','tx','rx']:
  a.add_patch(FancyBboxPatch((x-.5*s,y-.5*s),s,s,boxstyle='round,pad=.01',fc=c+'12',ec=c,lw=1.7))
  for v in [-.3,0,.3]:line([-.75,-.5],[v,v]);line([.5,.75],[v,v])
  line([-.3,-.12,.12,.3],[-.15,.2,-.2,.15])
 elif k=='screen':
  a.add_patch(FancyBboxPatch((x-.65*s,y-.35*s),1.3*s,.85*s,boxstyle='round,pad=.01',fc=c+'10',ec=c,lw=1.7));line([0,0],[-.35,-.7]);line([-.4,.4],[-.7,-.7]);line([-.4,-.15,.05,.4],[0,.2,-.1,.2])
 elif k in ['antenna','radio']:
  line([-.4,0,.4],[-.65,.3,-.65]);line([-.25,.25],[-.35,-.35]);a.add_patch(Circle((x,y+.3*s),.09*s,color=c))
  for d in [1,1.55]:a.add_patch(Arc((x,y+.3*s),d*s,d*s,theta1=30,theta2=150,ec=c,lw=1.5))
 elif k=='cable':
  line([-.7,-.25,.15,.7],[-.35,-.35,.35,.35]);line([-.7,-.25,.15,.7],[.35,.35,-.35,-.35])
 elif k=='fiber':
  for dy in [-.32,0,.32]:line([-.7,.65],[dy,dy]);a.add_patch(Circle((x+.65*s,y+dy*s),.065*s,color=O))
 elif k=='sat':
  a.add_patch(Rectangle((x-.2*s,y-.25*s),.4*s,.5*s,ec=c,fc=c+'15',lw=1.6))
  for v in [-.8,.35]:a.add_patch(Rectangle((x+v*s,y-.35*s),.45*s,.7*s,ec=c,fc=c+'25',lw=1.3))
  line([0,.35],[.25,.65]);a.add_patch(Arc((x+.35*s,y+.65*s),.55*s,.45*s,theta1=180,theta2=350,ec=c,lw=1.6))
 elif k=='sample':
  for xx,yy in zip([-.6,-.2,.2,.6],[.3,.7,.1,-.4]):line([xx,xx],[-.5,yy]);a.add_patch(Circle((x+xx*s,y+yy*s),.07*s,color=c))
 elif k=='level':line([-.7,-.35,-.35,0,0,.35,.35,.7],[-.5,-.5,-.15,-.15,.2,.2,.55,.55])
 elif k=='bits':a.text(x,y,'01',ha='center',va='center',fontsize=18,weight='bold',color=c)
 elif k=='filter':line([-.7,-.25,.15,.7],[.5,.5,-.4,-.4])

def card(a,x,y,w,h,title,detail,k,c=B):
 a.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.03,rounding_size=.13',fc='#F4F8FB',ec='#CCDAE4',lw=1));icon(a,x+w/2,y+h-.5,k,c,.48);a.text(x+w/2,y+.72,title,ha='center',weight='bold',fontsize=11,color=c);a.text(x+w/2,y+.27,detail,ha='center',fontsize=10)
def arrow(a,p,q,c=T):a.annotate('',xy=q,xytext=p,arrowprops={'arrowstyle':'-|>','lw':1.8,'color':c,'mutation_scale':13})
def clean(a,x,y):a.set_xlabel(x);a.set_ylabel(y);a.grid(alpha=.15);a.set_axisbelow(True)
f,a=canvas(4)
for x,y,head,body,k,c in [(0,3.45,'SOURCE','Voice or data','mic',B),(4.35,3.45,'TRANSMITTER','Create the waveform','tx',B),(8.7,3.45,'CHANNEL','Carry the waveform','antenna',O),(8.7,.25,'RECEIVER','Estimate the data','rx',T),(4.35,.25,'DESTINATION','Use the message','screen',T)]:card(a,x,y,3.25,2.1,head,body,k,c)
for p,q in [((3.35,4.5),(4.2,4.5)),((7.7,4.5),(8.55,4.5)),((10.3,3.35),(10.3,2.5)),((8.6,1.3),(7.75,1.3))]:arrow(a,p,q)
a.text(.1,1.6,'ONE MESSAGE',weight='bold',color=B);a.text(.1,.85,'Different representations.\nThe same information.',fontsize=11);save(f,'simple_link')
f,a=canvas(2.7)
for x,h,d,k,c in [(0,'SAMPLE','Select time instants','sample',B),(4.35,'QUANTIZE','Select amplitude levels','level',T),(8.7,'ENCODE','Assign binary words','bits',O)]:card(a,x,.75,3.25,2.4,h,d,k,c)
arrow(a,(3.35,1.95),(4.2,1.95));arrow(a,(7.7,1.95),(8.55,1.95));a.text(6,.15,'WHEN to measure   →   WHICH level   →   WHICH label',ha='center',weight='bold',color=N);save(f,'adc_stages')
f,a=canvas(3.7)
for x,h in [(0,'GUIDED • physical path'),(6.2,'UNGUIDED • waves in space')]:
 a.add_patch(FancyBboxPatch((x,.4),5.8,4.5,boxstyle='round,pad=.04,rounding_size=.12',fc='#F4F8FB',ec='#CCDCE5'));a.text(x+2.9,4.45,h,ha='center',weight='bold',color=B)
for x,items in [(0,[('cable','Twisted pair'),('fiber','Optical fiber'),('cable','Coaxial cable')]),(6.2,[('antenna','Terrestrial microwave'),('sat','Satellite'),('radio','Broadcast radio')])]:
 for j,(k,t) in enumerate(items):icon(a,x+.8,3.4-j*1.05,k,T,.43);a.text(x+1.65,3.4-j*1.05,t,va='center',fontsize=12)
save(f,'simple_channels')
f,a=canvas(2.7)
for x,h,d,k,c in [(0,'ANALOG FILTER','Reduce unwanted input','filter',B),(4.35,'SAMPLER','Measure at the rate fₛ','sample',T),(8.7,'DIGITAL FILTER','Process the samples','chip',O)]:card(a,x,.7,3.25,2.4,h,d,k,c)
arrow(a,(3.35,1.9),(4.2,1.9));arrow(a,(7.7,1.9),(8.55,1.9));a.text(6,.1,'6 kHz sampled at 8 ksample/s aliases to 2 kHz: filter BEFORE sampling.',ha='center',fontsize=10);save(f,'filter_order')
# Physical channel sections: illustrative dimensions, actual layer order.
f,axs=plt.subplots(1,3,figsize=(8,3.05),constrained_layout=True)
for a,title in zip(axs,['Twisted pair','Coaxial cable','Optical fiber']):a.set_aspect('equal');a.set(xlim=(-1.5,1.5),ylim=(-1.6,1.7));a.axis('off');a.set_title(title,color=B)
for x in [-.58,.58]:axs[0].add_patch(Circle((x,.5),.5,fc='#D9EAF8',ec=B,lw=1.5));axs[0].add_patch(Circle((x,.5),.25,fc=O,ec='white'))
axs[0].text(0,-.4,'Copper conductors',ha='center',weight='bold',fontsize=10);axs[0].text(0,-.95,'Insulation surrounds\neach conductor',ha='center',fontsize=10)
for rr,c in [(1.0,N),(.86,'#8FA6B8'),(.7,'#E5F1F3'),(.22,O)]:axs[1].add_patch(Circle((0,.5),rr,fc=c,ec='white',lw=1))
axs[1].text(0,-.95,'Center → dielectric\n→ shield → jacket',ha='center',fontsize=10)
for rr,c in [(1,O),(.8,'#D8EBF6'),(.28,T)]:axs[2].add_patch(Circle((0,.5),rr,fc=c,ec='white',lw=1))
axs[2].text(0,-.95,'Core → cladding\n→ protective coating',ha='center',fontsize=10)
f.text(.5,-.035,'Cross-sections are schematic; dimensions are not to scale.',ha='center',fontsize=9,color=G);save(f,'media_sections')
# Clean sampled waveform. Values are computed directly from the stated equation.
f,a=plt.subplots(figsize=(8,2.75),constrained_layout=True);t=np.linspace(0,.002,1601);tn=np.arange(17)/8000;y=np.cos(2*np.pi*1000*t);yn=np.cos(2*np.pi*1000*tn)
a.plot(t*1000,y,color=B,label='1 kHz cosine');a.vlines(tn*1000,0,yn,color=T,lw=1);a.scatter(tn*1000,yn,color=T,s=28,zorder=4,label='Samples at 8 ksample/s');a.set(xlim=(-.03,2.03),ylim=(-1.35,1.65));a.axhline(0,color=G,lw=.7);a.annotate('',(.875,1.2),(.75,1.2),arrowprops={'arrowstyle':'<->','color':O,'lw':1.5});a.text(.8125,1.4,'Tₛ = 125 μs',ha='center',color=O);a.legend(loc='lower left',ncol=2,frameon=False);clean(a,'Time (ms)','Voltage (V)');save(f,'sample_interval')
# Midrise uniform quantizer transfer and concrete error.
f,(a,b)=plt.subplots(1,2,figsize=(8,3),constrained_layout=True)
for j in range(8):
 lo=-1+j*.25;v=lo+.125;a.plot([lo,lo+.25],[v,v],color=B,lw=2.5)
a.plot([-1,1],[-1,1],ls='--',color=G,lw=1,label='No rounding');a.scatter([.31],[.375],color=O,s=40,zorder=5);a.annotate('0.31 V → 0.375 V',(.31,.375),xytext=(-.9,.8),arrowprops={'arrowstyle':'->','color':O},fontsize=10);a.set_title('Eight allowed output levels',loc='left');clean(a,'Input voltage (V)','Output voltage (V)');a.set_xticks([-1,-.5,0,.5,1]);a.set_yticks([-1,-.5,0,.5,1]);b.axis('off')
for y,h,tx,c in [(.78,'MEASURED VALUE','0.310 V',B),(.47,'SELECTED LEVEL','0.375 V',T),(.16,'ROUNDING ERROR','+0.065 V',O)]:b.text(.5,y,h,ha='center',weight='bold',color=c,fontsize=11);b.text(.5,y-.12,tx,ha='center',fontsize=18,color=N)
save(f,'quantization_detail')
# Reproducible random noise, no displaced pulse masquerading as attenuation.
f,axs=plt.subplots(3,1,figsize=(8,4.65),sharex=True,constrained_layout=True);t=np.linspace(0,5,1000);s=np.exp(-((t-2)/.42)**2);rng=np.random.default_rng(20261004)
for a,z,title,c in zip(axs,[.5*s,np.exp(-((t-2.25)/.72)**2),s+.075*rng.standard_normal(len(t))],['ATTENUATION  |  reduced amplitude','DISTORTION  |  changed shape and delay','NOISE  |  random added fluctuations'],[T,O,R]):
 a.plot(t,s,color=B,lw=1.7,label='Transmitted');a.plot(t,z,color=c,lw=1.3,label='Received');a.set_title(title,loc='left',fontsize=11);a.set_ylabel('Voltage (V)');a.set_ylim(-.3,1.3);a.legend(ncol=2,loc='upper right',frameon=False,fontsize=9);a.grid(alpha=.13)
axs[-1].set_xlabel('Time (ms)');save(f,'impairments')
# Exact spectral replica positions for B=2 kHz.
f,axs=plt.subplots(3,1,figsize=(8,4.7),sharex=True,constrained_layout=True);fr=np.linspace(-10,10,4001)
for a,fs,title in zip(axs,[6,4,3],['6 ksample/s: copies are separated','4 ksample/s: copies meet at the edges','3 ksample/s: copies overlap']):
 for k,c in [(-1,T),(0,B),(1,T)]:
  v=np.maximum(1-np.abs(fr-k*fs)/2,0);a.plot(fr,v,color=c,lw=1.8);a.fill_between(fr,0,v,color=c,alpha=.1)
 a.set_title(title,loc='left',fontsize=11);a.set_ylim(0,1.25);a.set_yticks([0,1]);a.set_ylabel('Relative\nmagnitude');a.grid(alpha=.13)
axs[-1].set_xlabel('Frequency (kHz)');axs[-1].set_xticks(np.arange(-8,9,2));save(f,'replicas')
# Product: exact bilateral impulse weights 1/4.
f,axs=plt.subplots(1,2,figsize=(8,2.9),constrained_layout=True);t=np.linspace(0,.002,2001);v=np.cos(4000*np.pi*t)*np.cos(1000*np.pi*t);assert np.max(abs(v-(.5*np.cos(5000*np.pi*t)+.5*np.cos(3000*np.pi*t))))<1e-12
axs[0].plot(t*1000,v,color=B);axs[0].set_title('Product in time',loc='left');clean(axs[0],'Time (ms)','Amplitude');axs[1].vlines([-2.5,-1.5,1.5,2.5],0,.25,color=T,lw=2.2);axs[1].scatter([-2.5,-1.5,1.5,2.5],[.25]*4,color=T);axs[1].set(xlim=(-3.2,3.2),ylim=(0,.34),xticks=[-2.5,-1.5,0,1.5,2.5],yticks=[0,.125,.25]);axs[1].set_title('Lines at 1.5 and 2.5 kHz',loc='left');clean(axs[1],'Frequency (kHz)','Impulse weight');save(f,'product_compact')
f,axs=plt.subplots(2,1,figsize=(8,4.4),sharex=True,constrained_layout=True);t=np.linspace(0,.04,2001)
for a,fs in zip(axs,[400,150]):
 ts=np.arange(int(.04*fs)+1)/fs;a.plot(t*1000,8*np.cos(2*np.pi*100*t),color=B,label='Original: 100 Hz');a.scatter(ts*1000,8*np.cos(2*np.pi*100*ts),s=32,color=T,label='Samples',zorder=4)
 if fs==150:
  a.plot(t*1000,8*np.cos(2*np.pi*50*t),ls='--',color=O,label='Alias: 50 Hz');assert np.allclose(np.cos(2*np.pi*100*ts),np.cos(2*np.pi*50*ts))
 a.set_title(f'Sampling at {fs} samples/s',loc='left');a.set(ylabel='Amplitude',ylim=(-11,13));a.grid(alpha=.13);a.legend(loc='upper right',ncol=3,frameon=False,fontsize=9)
axs[-1].set_xlabel('Time (ms)');save(f,'simple_alias')
f,a=plt.subplots(figsize=(8,2.9),constrained_layout=True);u=np.linspace(-4,4,1601);a.plot(u,np.sinc(u),color=B);a.scatter(np.arange(-4,5),np.sinc(np.arange(-4,5)),color=T,s=28,zorder=4);a.axhline(0,color=G,lw=.7);a.annotate('Weight = 1',(0,1),xytext=(1,1.15),arrowprops={'arrowstyle':'->','color':T},color=T);a.annotate('Zero at every other integer',(2,0),xytext=(.8,-.43),arrowprops={'arrowstyle':'->','color':T},color=T);a.set(ylim=(-.55,1.35),xticks=np.arange(-4,5));clean(a,'Normalized time (t − nTₛ) / Tₛ','Interpolation weight');save(f,'sinc_kernel')
f,axs=plt.subplots(2,1,figsize=(8,3.8),constrained_layout=True);t=np.linspace(-.02,.02,2001);axs[0].plot(t*1000,np.sinc(200*t)**2,color=B);axs[0].set_title('Squared sinc in time',loc='left');clean(axs[0],'Time (ms)','Amplitude');fr=np.linspace(-300,300,1801);sp=np.maximum(1-np.abs(fr)/200,0);axs[1].plot(fr,sp,color=T);axs[1].fill_between(fr,sp,color=T,alpha=.12);axs[1].set_title('Normalized spectrum: edges at ±200 Hz',loc='left');axs[1].set_xticks([-200,0,200]);clean(axs[1],'Frequency (Hz)','Relative magnitude');save(f,'sinc_squared')
# Bandpass overview and fold: well-separated endpoint labels.
f,axs=plt.subplots(2,1,figsize=(8,3.8),constrained_layout=True)
for lo in [-22.5,17.5]:axs[0].add_patch(Rectangle((lo,0),5,1,fc=B+'20',ec=B,lw=1.6))
axs[0].set(xlim=(-27,27),ylim=(0,1.3),xticks=[-22.5,0,22.5],yticks=[0,1]);axs[0].set_title('Real signal: positive and negative bands',loc='left');clean(axs[0],'Frequency (MHz)','Relative magnitude');axs[1].add_patch(Rectangle((11.25,0),11.6666667-11.25,1,fc=T+'20',ec=T,lw=1.6));axs[1].axvline(11.4,color=O,ls='--');axs[1].set(xlim=(11.1,11.85),ylim=(0,1.3),xticks=[11.25,11.4,11.6666667],xticklabels=['11.25','11.40','11.6667'],yticks=[0,1]);axs[1].set_title('A permitted sampling window for this band',loc='left');clean(axs[1],'Sampling rate (Msample/s)','Allowed window');save(f,'bandpass')
f,axs=plt.subplots(2,1,figsize=(8,3.8),constrained_layout=True)
axs[0].add_patch(Rectangle((17.5,0),5,1,fc=B+'20',ec=B,lw=1.5));axs[0].axvline(22.8,color=O,ls='--');axs[0].set(xlim=(16.5,24),ylim=(0,1.45),xticks=[17.5,22.5],yticks=[0,1]);axs[0].annotate('2fₛ = 22.8',(22.8,.6),xytext=(20.5,1.2),arrowprops={'arrowstyle':'->','color':O},color=O);axs[0].set_title('Original positive-frequency band',loc='left');clean(axs[0],'Input frequency (MHz)','Relative magnitude')
axs[1].add_patch(Rectangle((.3,0),5,1,fc=T+'20',ec=T,lw=1.5));axs[1].axvline(5.7,color=O,ls='--');axs[1].set(xlim=(-.3,6.5),ylim=(0,1.45),xticks=[.3,5.3],yticks=[0,1]);axs[1].annotate('fₛ / 2 = 5.7',(5.7,.6),xytext=(3.4,1.2),arrowprops={'arrowstyle':'->','color':O},color=O);axs[1].set_title('Folded band: 0.3 to 5.3 MHz',loc='left');clean(axs[1],'Folded frequency (MHz)','Relative magnitude');save(f,'bandpass_fold')
print('Redrew 16 vector figures. Analytical checks passed.')
f,a=canvas(4.5)
for x,y,h,d,k,c in [(0,4.5,'SOURCE','ADC or native data','mic',B),(4.35,4.5,'CODING','Represent and protect','bits',B),(8.7,4.5,'TRANSMITTER','Shape and modulate','tx',B),(8.7,.25,'RECEIVER','Filter and decide','rx',T),(4.35,.25,'DECODING','Recover information','chip',T),(0,.25,'DESTINATION','Display or play','screen',T)]:card(a,x,y,3.25,2.0,h,d,k,c)
for p,q in [((3.35,5.5),(4.2,5.5)),((7.7,5.5),(8.55,5.5)),((8.6,1.25),(7.75,1.25)),((4.25,1.25),(3.4,1.25))]:arrow(a,p,q)
a.add_patch(FancyBboxPatch((8.7,2.8),3.25,1,boxstyle='round,pad=.03',fc=O+'10',ec=O));a.text(10.3,3.3,'CHANNEL',ha='center',va='center',weight='bold',color=O);arrow(a,(10.3,4.4),(10.3,3.9));arrow(a,(10.3,2.7),(10.3,2.35));a.text(10.6,4.08,'s(t)',fontsize=10);a.text(10.6,2.4,'r(t)',fontsize=10)
a.text(.15,3.8,'TRANSMIT →',color=B,weight='bold');a.text(.15,3.25,'← RECEIVE',color=T,weight='bold');a.text(3.6,3.35,'r(t) = s(t) + n(t)',fontsize=13);a.text(3.6,2.85,'Simple additive-noise model',fontsize=10,color=G);save(f,'architecture')
f,axs=plt.subplots(2,1,figsize=(8,3.8),constrained_layout=True);u=np.linspace(-3,3,1201)
for n,c in [(-1,O),(0,B),(1,T)]:axs[0].plot(u,np.cos(.6*np.pi*n)*np.sinc(u-n),color=c,label=f'n = {n}')
axs[0].set_title('Three individual sample contributions',loc='left');axs[0].legend(frameon=False,ncol=3,loc='upper right');clean(axs[0],'Time / sample interval','Contribution')
n=np.arange(-500,501);s=np.cos(.6*np.pi*n);yr=s@np.sinc(u[None,:]-n[:,None]);ideal=np.cos(.6*np.pi*u);assert np.max(np.abs(yr-ideal))<1e-4
axs[1].plot(u,ideal,color=B,label='Original cosine');axs[1].plot(u,yr,color=T,ls='--',label='Sinc sum (1001 terms)');nn=np.arange(-3,4);axs[1].scatter(nn,np.cos(.6*np.pi*nn),color=T,s=20,zorder=5);axs[1].set_title('Adding the contributions reconstructs the waveform',loc='left');axs[1].legend(frameon=False,loc='upper right',fontsize=8);clean(axs[1],'Time / sample interval','Amplitude');save(f,'reconstruction')
